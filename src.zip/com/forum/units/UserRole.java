package com.forum.units;

public enum UserRole {
	ADMIN, MODERATOR, USER
}
